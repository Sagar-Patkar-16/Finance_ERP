/* ============================================================
   Sidebar + Topbar — shared across all pages (§10.2)
   ============================================================ */
import { icon } from './components.js';
import { getSession, clearSession, toggleTheme, rootPath } from './app.js';

/* Left navigation IA — full §10.2 coverage + advanced additions */
export const NAV_STRUCTURE = [
  { group: 'Home', items: [
    { label: 'Dashboard', icon: 'home', href: 'pages/dashboard.html' },
  ]},
  { group: 'Finance', items: [
    { label: 'General Ledger',      icon: 'file-text',      href: 'pages/finance-gl.html' },
    { label: 'Accounts Payable',    icon: 'arrow-up-right', href: 'pages/finance-ap.html' },
    { label: 'Accounts Receivable', icon: 'arrow-down-left',href: 'pages/finance-ar.html' },
    { label: 'Banking & Recon',     icon: 'building',       href: 'pages/bank-recon.html' },
    { label: 'Fixed Assets',        icon: 'layers',         href: 'pages/fixed-assets.html' },
    { label: 'Cash Flow',           icon: 'dollar-sign',    href: 'pages/cash-flow.html' },
    { label: 'Tax & Compliance',    icon: 'clipboard',      href: 'pages/tax-compliance.html' },
  ]},
  { group: 'Sales & CRM', items: [
    { label: 'Pipeline',       icon: 'grid',       href: 'pages/crm-pipeline.html' },
    { label: 'Customers',      icon: 'users',      href: 'pages/customer-360.html' },
    { label: 'Quotations',     icon: 'file-text',  href: 'pages/quotation.html' },
    { label: 'Sales Orders',   icon: 'clipboard',  href: 'pages/sales-order.html' },
    { label: 'Sales Invoices', icon: 'dollar-sign',href: 'pages/sales-invoice.html' },
    { label: 'Price Lists',    icon: 'layers',     href: 'pages/price-lists.html' },
  ]},
  { group: 'Purchasing', items: [
    { label: 'Dashboard',        icon: 'bar-chart', href: 'pages/purchase-dashboard.html' },
    { label: 'Vendors',          icon: 'briefcase', href: 'pages/vendor-360.html' },
    { label: 'Requisitions',     icon: 'file-text', href: 'pages/purchase-requisition.html' },
    { label: 'RFQ Comparison',   icon: 'layers',    href: 'pages/rfq-comparison.html' },
    { label: 'Purchase Orders',  icon: 'clipboard', href: 'pages/purchase-order.html' },
    { label: 'Goods Receipt',    icon: 'package',   href: 'pages/goods-receipt.html' },
    { label: 'Vendor Invoices',  icon: 'dollar-sign',href: 'pages/vendor-invoice.html' },
    { label: '3-Way Match',      icon: 'check-circle', href: 'pages/three-way-match.html' },
    { label: 'Vendor Scorecard', icon: 'bar-chart', href: 'pages/vendor-scorecard.html' },
  ]},
  { group: 'Inventory', items: [
    { label: 'Dashboard',      icon: 'bar-chart', href: 'pages/inventory-dashboard.html' },
    { label: 'Warehouses',     icon: 'building',  href: 'pages/warehouse-bin.html' },
    { label: 'Stock Movement', icon: 'truck',     href: 'pages/stock-movement.html' },
    { label: 'Barcode / QR',   icon: 'cpu',       href: 'pages/barcode.html' },
    { label: 'Cycle Count',    icon: 'refresh-cw',href: 'pages/cycle-count.html' },
    { label: 'Batch & Serial', icon: 'layers',    href: 'pages/batch-serial.html' },
  ]},
  { group: 'Supply Chain', items: [
    { label: 'Demand Forecast', icon: 'activity',  href: 'pages/demand-forecast.html' },
    { label: 'MRP',             icon: 'cpu',       href: 'pages/mrp.html' },
    { label: 'Replenishment',   icon: 'refresh-cw',href: 'pages/replenishment.html' },
    { label: 'Supplier Lead Time', icon: 'clock',  href: 'pages/supplier-lead-time.html' },
  ]},
  { group: 'Manufacturing', items: [
    { label: 'Dashboard',         icon: 'bar-chart', href: 'pages/manufacturing-dashboard.html' },
    { label: 'BOM',               icon: 'layers',    href: 'pages/bom.html' },
    { label: 'Routing',           icon: 'cpu',       href: 'pages/routing.html' },
    { label: 'Work Centers',      icon: 'settings',  href: 'pages/work-centers.html' },
    { label: 'Machines',          icon: 'cpu',       href: 'pages/machines.html' },
    { label: 'Production Orders', icon: 'factory',   href: 'pages/production-order.html' },
    { label: 'Quality Control',   icon: 'check-circle', href: 'pages/quality-control.html' },
    { label: 'Capacity',          icon: 'activity',  href: 'pages/capacity.html' },
    { label: 'OEE Monitor',       icon: 'pie-chart', href: 'pages/oee-monitor.html' },
  ]},
  { group: 'HRMS', items: [
    { label: 'Employees',    icon: 'users',        href: 'pages/hrms-employees.html' },
    { label: 'Recruitment',  icon: 'briefcase',    href: 'pages/recruitment.html' },
    { label: 'Attendance',   icon: 'clock',        href: 'pages/attendance.html' },
    { label: 'Leave',        icon: 'activity',     href: 'pages/leave.html' },
    { label: 'Payroll',      icon: 'dollar-sign',  href: 'pages/payroll.html' },
    { label: 'Performance',  icon: 'trending-up',  href: 'pages/performance.html' },
    { label: 'Training',     icon: 'clipboard',    href: 'pages/training.html' },
  ]},
  { group: 'Intelligence', items: [
    { label: 'AI Copilot',  icon: 'bot',           href: 'pages/ai-copilot.html' },
    { label: 'Insights',    icon: 'sparkles',      href: 'pages/insights.html' },
    { label: 'Forecasting', icon: 'trending-up',   href: 'pages/ai-forecasting.html' },
    { label: 'Anomalies',   icon: 'alert-triangle',href: 'pages/anomalies.html' },
    { label: 'Automation',  icon: 'zap',           href: 'pages/automation.html' },
    { label: 'Analytics',   icon: 'bar-chart',     href: 'pages/analytics.html' },
  ]},
  { group: 'Administration', items: [
    { label: 'Users',      icon: 'users',    href: 'pages/admin-users.html' },
    { label: 'Roles',      icon: 'settings', href: 'pages/admin-roles.html' },
    { label: 'Workflows',  icon: 'zap',      href: 'pages/automation.html' },
    { label: 'Audit Trail',icon: 'eye',      href: 'pages/audit-trail.html' },
    { label: 'Integrations', icon: 'layers', href: 'pages/integrations.html' },
    { label: 'Settings',   icon: 'settings', href: 'pages/system-settings.html' },
  ]},
];

/* Detect whether we're in /pages/ and adjust links */
function hrefFor(href) {
  const inPages = location.pathname.includes('/pages/');
  if (inPages) return href.replace(/^pages\//, '');
  return href;
}

function currentPage() {
  return location.pathname.split('/').pop() || 'dashboard.html';
}

export function renderSidebar() {
  const cur = currentPage();
  const groups = NAV_STRUCTURE.map(g => `
    <div class="nav-group">
      <div class="nav-group-title">${g.group}</div>
      ${g.items.map(it => {
        const isActive = hrefFor(it.href).endsWith(cur);
        return `<a class="nav-item ${isActive ? 'active' : ''}" href="${hrefFor(it.href)}" data-tooltip="${it.label}">
          <span class="nav-icon">${icon(it.icon, 18)}</span>
          <span class="nav-label">${it.label}</span>
        </a>`;
      }).join('')}
    </div>
  `).join('');

  return `
    <aside class="sidebar" id="sidebar">
      <div class="sidebar-brand">
        <div class="sidebar-brand-logo">E</div>
        <div class="sidebar-brand-name">ERP Platform</div>
      </div>
      <nav class="sidebar-nav">${groups}</nav>
      <div class="sidebar-footer">
        <button class="nav-item" id="themeToggle" data-tooltip="Toggle theme">
          <span class="nav-icon" id="themeIcon">${icon('moon', 18)}</span>
          <span class="nav-label">Toggle theme</span>
        </button>
      </div>
    </aside>
    <div class="mobile-backdrop" id="mobileBackdrop"></div>
  `;
}

export function renderTopbar({ breadcrumb = [], notifications = [] }) {
  const s = getSession() || {};
  const unread = notifications.filter(n => !n.read).length;
  const bcHtml = breadcrumb.map((b, i) => {
    const last = i === breadcrumb.length - 1;
    return last
      ? `<span class="breadcrumb-current">${b}</span>`
      : `<a href="#">${b}</a><span class="breadcrumb-sep">/</span>`;
  }).join('');

  return `
    <header class="topbar">
      <div class="topbar-left">
        <button class="icon-btn" id="mobileMenuBtn" aria-label="Menu" style="display:none">${icon('menu', 18)}</button>
        <button class="icon-btn" id="sidebarToggle" aria-label="Collapse sidebar">${icon('menu', 18)}</button>
        <div class="breadcrumb">${bcHtml}</div>
      </div>
      <button class="search-trigger" id="openSearch">
        ${icon('search', 16)} <span>Search anything…</span> <kbd>⌘K</kbd>
      </button>
      <div class="topbar-right">
        <button class="icon-btn" id="themeToggleTop" aria-label="Toggle theme">${icon('sun', 18)}</button>
        <button class="icon-btn" id="notifBtn" aria-label="Notifications" style="position:relative">
          ${icon('bell', 18)}
          ${unread > 0 ? `<span class="badge-dot pulse"></span>` : ''}
        </button>
        <div class="user-chip" id="userChip">
          <div class="avatar">${s.initials || 'U'}</div>
          <div class="user-meta">
            <span class="name">${s.name || 'User'}</span>
            <span class="role">${s.role || 'Guest'}</span>
          </div>
          ${icon('chevron-down', 14)}
        </div>
      </div>
    </header>`;
}

/* Global search modal */
export function renderSearchModal() {
  return `
    <div class="modal-backdrop" id="searchModal">
      <div class="modal" style="max-width:560px;align-self:flex-start;margin-top:80px">
        <div class="modal-body" style="padding:0">
          <div class="input-search" style="padding:12px">
            ${icon('search', 16)}
            <input class="input" id="searchInput" placeholder="Search customers, vendors, items, POs…" autofocus>
          </div>
          <div id="searchResults" style="padding:0 12px 16px">
            <div class="text-muted" style="font-size:12px;padding:8px">Type to search across all modules</div>
          </div>
        </div>
      </div>
    </div>`;
}

/* Wire up common topbar/nav interactions */
export function bindNav({ notifications = [] } = {}) {
  const sidebar = document.getElementById('sidebar');
  const app = document.querySelector('.app');
  const backdrop = document.getElementById('mobileBackdrop');

  const mobile = () => window.matchMedia('(max-width: 768px)').matches;

  document.getElementById('sidebarToggle')?.addEventListener('click', () => {
    if (mobile()) {
      sidebar.classList.toggle('open');
      backdrop.classList.toggle('open');
    } else {
      app.classList.toggle('sidebar-collapsed');
      localStorage.setItem('erp-sidebar-collapsed', app.classList.contains('sidebar-collapsed'));
    }
  });

  const mmb = document.getElementById('mobileMenuBtn');
  if (mmb && mobile()) mmb.style.display = 'grid';

  backdrop?.addEventListener('click', () => {
    sidebar.classList.remove('open');
    backdrop.classList.remove('open');
  });

  // Theme toggles
  ['themeToggle', 'themeToggleTop'].forEach(id => {
    document.getElementById(id)?.addEventListener('click', () => {
      toggleTheme();
      const t = document.documentElement.getAttribute('data-theme');
      document.getElementById('themeIcon').innerHTML = icon(t === 'dark' ? 'sun' : 'moon', 18);
    });
  });

  // Notification drawer
  document.getElementById('notifBtn')?.addEventListener('click', async () => {
    const drawer = document.getElementById('notifDrawer');
    if (!drawer) return;
    const html = await import('./components.js').then(m => m.renderNotificationDrawer(notifications));
    drawer.innerHTML = html;
    drawer.classList.add('open');
    drawer.querySelector('[data-close-drawer]')?.addEventListener('click', () => drawer.classList.remove('open'));
  });

  // Global search
  const searchModal = document.getElementById('searchModal');
  const openSearch = () => { searchModal.classList.add('open'); document.getElementById('searchInput')?.focus(); };
  const closeSearch = () => searchModal.classList.remove('open');

  document.getElementById('openSearch')?.addEventListener('click', openSearch);
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openSearch(); }
    if (e.key === 'Escape') { closeSearch(); document.getElementById('notifDrawer')?.classList.remove('open'); }
  });
  searchModal?.addEventListener('click', e => { if (e.target === searchModal) closeSearch(); });

  // User chip → logout menu
  document.getElementById('userChip')?.addEventListener('click', async () => {
    const ok = await import('./components.js').then(m => m.confirmDialog({
      title: 'Sign out?', message: 'You will be returned to the login screen.',
      confirmText: 'Sign out', variant: 'danger'
    }));
    if (ok) { clearSession(); location.href = (location.pathname.includes('/pages/') ? '../' : './') + 'index.html'; }
  });
}

/* Helper: mount shell into a page */
export function mountShell({ breadcrumb, notifications = [] }) {
  const app = document.querySelector('.app');
  app.insertAdjacentHTML('afterbegin', renderSidebar());
  app.querySelector('.topbar').outerHTML = renderTopbar({ breadcrumb, notifications });
  document.body.insertAdjacentHTML('beforeend', renderSearchModal());
  document.body.insertAdjacentHTML('beforeend', `<aside class="drawer" id="notifDrawer"></aside>`);
  bindNav({ notifications });

  // restore collapsed state
  if (localStorage.getItem('erp-sidebar-collapsed') === 'true') {
    app.classList.add('sidebar-collapsed');
  }
}