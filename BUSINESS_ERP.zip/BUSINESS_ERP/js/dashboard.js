/* ============================================================
   Dashboard — role-based widgets (§10.5)
   ============================================================ */
import { requireAuth, rootPath, fmtCurrencyINR, toggleDensity } from './app.js';
import { mountShell } from './nav.js';
import { kpiCard, statusChip, icon, toast } from './components.js';
import { lineChart } from './charts.js';
import * as api from './api.js';

const session = requireAuth();
const notifications = await api.getNotifications();

mountShell({ breadcrumb: ['Home', 'Dashboard'], notifications });

/* ---------- Welcome ---------- */
const hour = new Date().getHours();
const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
document.getElementById('welcomeTitle').textContent = `${greeting}, ${session.name.split(' ')[0]}`;
document.getElementById('welcomeSub').textContent = `${session.role} · ${new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}`;

/* ---------- KPI row (role-based §10.5) ---------- */
const kpis = await api.getRoleDashboard(session.role);
const kpiRow = document.getElementById('kpiRow');
if (kpis.length === 0) {
  kpiRow.innerHTML = `<div class="card"><div class="card-body text-muted">No KPI widgets configured for your role.</div></div>`;
} else {
  kpiRow.innerHTML = kpis.map(k => kpiCard({
    label: k.label, value: k.value, delta: k.delta, icon: k.icon
  })).join('');
}

/* ---------- Sales trend chart ---------- */
const trend = await api.getSalesTrend();
lineChart('salesTrendChart', {
  labels: trend.labels,
  datasets: [
    { label: 'Actual', data: trend.actual, color: cssVar('--chart-1'), fill: true },
    { label: 'Forecast', data: trend.forecast, color: cssVar('--chart-2'), dashed: true },
  ]
});

/* ---------- AI alerts ---------- */
const alerts = await api.getAiAlerts();
document.getElementById('alertCount').textContent = `${alerts.length} alerts · ${alerts.filter(a => a.level === 'critical').length} critical`;

const alertRow = (a) => `
  <div style="display:flex;gap:10px;padding:10px;border-radius:8px;margin-bottom:6px;cursor:pointer;transition:background var(--t-fast)" onmouseover="this.style.background='var(--surface-alt)'" onmouseout="this.style.background='transparent'">
    <span style="color:var(--${a.level});flex-shrink:0">${icon(levelToIcon(a.level), 18)}</span>
    <div style="flex:1;min-width:0">
      <div style="font-size:13px;font-weight:600">${a.title}</div>
      <div style="font-size:12px;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis">${a.msg}</div>
      <div style="font-size:11px;color:var(--text-faint);margin-top:3px">${a.module} · ${a.ts}</div>
    </div>
  </div>
`;
document.getElementById('alertList').innerHTML = alerts.map(alertRow).join('');

/* ---------- Workflow strip ---------- */
const wf = [
  { label: 'PRs pending',    value: 3, chip: 'warning' },
  { label: 'POs in transit', value: 5, chip: 'info' },
  { label: 'Invoices due',   value: 12, chip: 'attention' },
  { label: 'Production',     value: 3, chip: 'success' },
];
document.getElementById('workflowStrip').innerHTML = wf.map(w => `
  <div class="kpi" style="cursor:pointer">
    <div class="kpi-header">
      <span class="kpi-label">${w.label}</span>
    </div>
    <div class="kpi-value">${w.value}</div>
    ${statusChip(w.chip, w.label.split(' ')[0])}
  </div>`).join('');

/* ---------- Recent activity ---------- */
const activity = [
  { who: 'Vikram Rao', what: 'created PO-2015 for Vendor D', when: '12 min ago', icon: 'file-text' },
  { who: 'Anita Sharma', what: 'approved PO-2011', when: '1 hr ago', icon: 'check-circle' },
  { who: 'Priya Nair', what: 'marked PRO-1042 as Completed', when: '3 hr ago', icon: 'factory' },
  { who: 'Suresh Kumar', what: 'adjusted IT-100 stock by +120', when: '5 hr ago', icon: 'package' },
];
document.getElementById('recentActivity').innerHTML = activity.map(a => `
  <div style="display:flex;gap:12px;padding:10px 0;border-bottom:1px solid var(--border)">
    <div class="kpi-icon" style="width:32px;height:32px">${icon(a.icon, 16)}</div>
    <div style="flex:1">
      <div style="font-size:13px"><b>${a.who}</b> ${a.what}</div>
      <div style="font-size:11px;color:var(--text-faint)">${a.when}</div>
    </div>
  </div>`).join('');

/* ---------- Interaction ---------- */
document.getElementById('densityBtn').addEventListener('click', (e) => {
  const next = toggleDensity();
  e.target.textContent = next.charAt(0).toUpperCase() + next.slice(1);
  toast('Density changed', `Switched to ${next} mode`, 'info', 1800);
});

document.getElementById('viewAllAlerts').addEventListener('click', () => location.href = 'anomalies.html');
document.getElementById('viewWorkflows').addEventListener('click', () => location.href = 'automation.html');

document.getElementById('newActionBtn').addEventListener('click', () => {
  toast('Quick create', 'Choose a module to start a new record', 'info');
});

document.getElementById('rangeSeg').addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  document.querySelectorAll('#rangeSeg button').forEach(b => b.classList.toggle('active', b === e.target));
  toast('Range updated', `Showing ${e.target.dataset.range}`, 'info', 1500);
});

/* helpers */
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
function levelToIcon(level) {
  return { critical:'alert-circle', warning:'alert-triangle', attention:'clock', info:'info', success:'check-circle' }[level] || 'info';
}