/* ============================================================
   API Layer — SINGLE SWAP POINT for real backend
   ------------------------------------------------------------
   Today: returns MOCK data.
   Tomorrow: comment MOCK line, uncomment fetch line.
   Contract shapes stay identical.
   ============================================================ */

const API_BASE = '/api'; // Point to FastAPI host in production

/* ------------------------------------------------------------------
   MOCK DATA — clearly separated so it's easy to delete later
   ------------------------------------------------------------------ */
const MOCK = {
  companies: [
    { id: 'c1', name: 'Acme Industries Pvt Ltd', fy: '2026-27', role: 'CEO' },
    { id: 'c2', name: 'Acme Pharma Division',   fy: '2026-27', role: 'CFO' },
    { id: 'c3', name: 'Acme Engineering Works', fy: '2026-27', role: 'Purchase Manager' },
  ],

  demoUsers: [
    { email: 'ceo@acme.com',       password: 'demo', name: 'Rahul Mehta',   role: 'CEO',              initials: 'RM' },
    { email: 'cfo@acme.com',       password: 'demo', name: 'Anita Sharma',  role: 'CFO',              initials: 'AS' },
    { email: 'purchase@acme.com',  password: 'demo', name: 'Vikram Rao',    role: 'Purchase Manager', initials: 'VR' },
    { email: 'warehouse@acme.com', password: 'demo', name: 'Suresh Kumar',  role: 'Warehouse Manager',initials: 'SK' },
    { email: 'production@acme.com',password: 'demo', name: 'Priya Nair',    role: 'Production Manager',initials:'PN' },
    { email: 'hr@acme.com',        password: 'demo', name: 'Kavita Iyer',   role: 'HR Manager',       initials: 'KI' },
  ],

  /* Executive dashboard KPIs (§5.8) */
  execKpis: {
    revenue:  { value: 124000000, label: 'Revenue',   delta: +12.4, icon: 'trending-up' },
    profit:   { value: 28000000,  label: 'Profit',    delta: +8.2,  icon: 'wallet' },
    cash:     { value: 41000000,  label: 'Cash',      delta: -3.1,  icon: 'banknote' },
    inventory:{ value: 32000000,  label: 'Inventory', delta: +1.8,  icon: 'package' },
    receivable:{value: 18000000,  label: 'Receivable',delta: +4.5,  icon: 'arrow-down-left' },
    payable:  { value: 11000000,  label: 'Payable',   delta: -2.2,  icon: 'arrow-up-right' },
  },

  /* Role-based dashboard widget sets (§10.5) */
  roleDashboards: {
    'CEO': ['revenue','profit','cash','inventory','receivable','payable'],
    'CFO': ['receivable','payable','cash','inventory'],
    'Purchase Manager': ['payable','inventory'],
    'Warehouse Manager': ['inventory'],
    'Production Manager': ['inventory'],
    'HR Manager': [],
  },

  /* Sales trend (dashboard chart) */
  salesTrend: {
    labels: ['Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec','Jan','Feb','Mar'],
    actual:   [8.2, 8.9, 9.4, 10.1, 10.8, 11.2, 11.8, 12.1, 12.4, 11.9, 12.2, 12.6],
    forecast: [null,null,null,null,null,null,null,null,12.4, 12.1, 12.9, 13.6],
  },

  /* AI Alerts (§5.8 notification palette) */
  aiAlerts: [
    { id: 'a1', level: 'critical',  title: 'Stockout predicted', msg: 'IT-100 Steel Plate projected below safety stock in 12 days', module: 'Inventory', ts: '5 min ago' },
    { id: 'a2', level: 'warning',   title: 'Vendor price anomaly', msg: 'Vendor A price +22% vs previous PO on IT-205', module: 'Purchasing', ts: '1 hr ago' },
    { id: 'a3', level: 'attention', title: 'Contract expiring', msg: 'Vendor B contract expires in 18 days', module: 'Purchasing', ts: '3 hr ago' },
    { id: 'a4', level: 'info',      title: 'Production order complete', msg: 'PO-1042 finished goods received', module: 'Manufacturing', ts: '5 hr ago' },
    { id: 'a5', level: 'success',   title: 'PO approved', msg: 'PO-2011 approved by CFO', module: 'Purchasing', ts: 'Yesterday' },
  ],

  notifications: [
    { id: 'n1', level: 'critical',  title: 'Stockout predicted', msg: 'IT-100 below safety stock in 12 days', ts: '5 min ago', read: false },
    { id: 'n2', level: 'warning',   title: 'Invoice approval pending', msg: 'INV-3021 awaiting CFO approval', ts: '22 min ago', read: false },
    { id: 'n3', level: 'attention', title: 'Vendor contract expiring', msg: 'Vendor B — 18 days', ts: '3 hr ago', read: false },
    { id: 'n4', level: 'info',      title: 'Production order completed', msg: 'PO-1042', ts: '5 hr ago', read: true },
    { id: 'n5', level: 'success',   title: 'PO approved', msg: 'PO-2011 approved', ts: 'Yesterday', read: true },
  ],

  /* Customers (Customer 360 data) */
  customers: [
    { id: 'CU-001', name: 'ABC Industries',    contact: 'Ramesh K', phone: '+91 98xxx 11111', email: 'ramesh@abc.com', revenue: 24000000, outstanding: 1800000, orders: 142, avgPaymentDays: 34, creditLimit: 5000000, gst: '27AAACA1234B1Z5', status: 'Active' },
    { id: 'CU-002', name: 'XYZ Manufacturing', contact: 'Sunil P',  phone: '+91 98xxx 22222', email: 'sunil@xyz.com',  revenue: 18500000, outstanding: 950000,  orders: 98,  avgPaymentDays: 28, creditLimit: 4000000, gst: '27AAACX5678C1Z2', status: 'Active' },
    { id: 'CU-003', name: 'PQR Engineering',   contact: 'Meena R',  phone: '+91 98xxx 33333', email: 'meena@pqr.com',  revenue: 12000000, outstanding: 2400000, orders: 76,  avgPaymentDays: 52, creditLimit: 3000000, gst: '27AAACP9012D1Z8', status: 'Active' },
    { id: 'CU-004', name: 'LMN Pharma',        contact: 'Arjun S',  phone: '+91 98xxx 44444', email: 'arjun@lmn.com',  revenue: 31000000, outstanding: 4200000, orders: 210, avgPaymentDays: 41, creditLimit: 8000000, gst: '27AAACL3456E1Z1', status: 'Active' },
    { id: 'CU-005', name: 'DEF Tools',         contact: 'Nisha B',  phone: '+91 98xxx 55555', email: 'nisha@def.com',  revenue: 8200000,  outstanding: 0,       orders: 54,  avgPaymentDays: 22, creditLimit: 2000000, gst: '27AAACD7890F1Z9', status: 'Dormant' },
  ],

  /* Vendors (Vendor 360 + RFQ comparison) */
  vendors: [
    { id: 'V-001', name: 'Vendor A', contact: 'Kiran M',  phone: '+91 90xxx 11111', email: 'kiran@va.com',  category: 'Raw Material', terms: '30 Days', currency: 'INR', rating: 4.5, spend: 8500000,  outstanding: 620000, price: 100, delivery: 7,  payTerms: '30 Days' },
    { id: 'V-002', name: 'Vendor B', contact: 'Farhan A', phone: '+91 90xxx 22222', email: 'farhan@vb.com', category: 'Raw Material', terms: '45 Days', currency: 'INR', rating: 4.0, spend: 6200000,  outstanding: 320000, price: 95,  delivery: 15, payTerms: '45 Days' },
    { id: 'V-003', name: 'Vendor C', contact: 'Anil K',   phone: '+91 90xxx 33333', email: 'anil@vc.com',   category: 'Components',   terms: '30 Days', currency: 'INR', rating: 4.7, spend: 9800000,  outstanding: 1240000, price: 110, delivery: 5,  payTerms: '30 Days' },
    { id: 'V-004', name: 'Vendor D', contact: 'Pooja S',  phone: '+91 90xxx 44444', email: 'pooja@vd.com',  category: 'Packaging',    terms: '15 Days', currency: 'INR', rating: 3.8, spend: 3100000,  outstanding: 180000, price: 65,  delivery: 10, payTerms: '15 Days' },
  ],

  /* Items */
  items: [
    { code: 'IT-100', name: 'Steel Plate 5mm',   category: 'Raw Material', uom: 'KG',    stock: 80,  safety: 100, demand: 150, leadTime: 15, reorder: 100, valuation: 'FIFO', value: 240000 },
    { code: 'IT-205', name: 'Aluminium Sheet',   category: 'Raw Material', uom: 'KG',    stock: 420, safety: 200, demand: 180, leadTime: 10, reorder: 250, valuation: 'FIFO', value: 890000 },
    { code: 'IT-310', name: 'Bearing SKF-6205',  category: 'Component',    uom: 'PCS',   stock: 45,  safety: 80,  demand: 120, leadTime: 20, reorder: 100, valuation: 'WAvg', value: 135000 },
    { code: 'IT-401', name: 'Motor 5HP',         category: 'Component',    uom: 'PCS',   stock: 12,  safety: 15,  demand: 18,  leadTime: 25, reorder: 20,  valuation: 'WAvg', value: 360000 },
    { code: 'IT-550', name: 'Copper Wire 2mm',   category: 'Raw Material', uom: 'MTR',   stock: 1200,safety: 800, demand: 900, leadTime: 8,  reorder: 900, valuation: 'FIFO', value: 180000 },
  ],

  /* Purchase Orders */
  purchaseOrders: [
    { id: 'PO-2011', vendor: 'Vendor A', date: '2026-08-20', amount: 480000,  status: 'Approved',  expected: '2026-08-27' },
    { id: 'PO-2012', vendor: 'Vendor C', date: '2026-08-21', amount: 1250000, status: 'Sent',      expected: '2026-09-01' },
    { id: 'PO-2013', vendor: 'Vendor B', date: '2026-08-22', amount: 320000,  status: 'Draft',     expected: '2026-09-05' },
    { id: 'PO-2014', vendor: 'Vendor A', date: '2026-08-23', amount: 780000,  status: 'Approved',  expected: '2026-08-30' },
    { id: 'PO-2015', vendor: 'Vendor D', date: '2026-08-24', amount: 95000,   status: 'Pending',   expected: '2026-09-02' },
  ],

  /* Purchase Requisitions */
  purchaseRequisitions: [
    { id: 'PR-101', dept: 'Production', item: 'IT-100 Steel Plate 5mm', qty: 500, amount: 50000, status: 'Pending', date: '2026-08-24' },
    { id: 'PR-102', dept: 'Maintenance', item: 'IT-310 Bearing SKF-6205', qty: 200, amount: 120000, status: 'Approved', date: '2026-08-22' },
    { id: 'PR-103', dept: 'Production', item: 'IT-401 Motor 5HP', qty: 25, amount: 750000, status: 'Pending', date: '2026-08-23' },
  ],

  /* Invoices */
  invoices: [
    { id: 'INV-3021', customer: 'ABC Industries', amount: 850000,  due: '2026-09-05', status: 'Pending' },
    { id: 'INV-3022', customer: 'LMN Pharma',     amount: 1240000, due: '2026-08-30', status: 'Overdue' },
    { id: 'INV-3023', customer: 'XYZ Manufacturing', amount: 420000, due: '2026-09-10', status: 'Paid' },
    { id: 'INV-3024', customer: 'PQR Engineering', amount: 680000, due: '2026-09-15', status: 'Pending' },
  ],

  /* Production Orders */
  productionOrders: [
    { id: 'PRO-1042', product: 'Pump Assembly A', qty: 50, status: 'Completed',  progress: 100, due: '2026-08-22' },
    { id: 'PRO-1043', product: 'Motor Frame B',   qty: 120, status: 'In Progress', progress: 65,  due: '2026-08-28' },
    { id: 'PRO-1044', product: 'Bracket C',       qty: 300, status: 'Planned',    progress: 0,   due: '2026-09-05' },
  ],

  /* Employees */
  employees: [
    { id: 'E-001', name: 'Rajesh Kumar',  dept: 'Production',   designation: 'Sr. Engineer', joined: '2019-04-12', status: 'Active', email: 'rajesh@acme.com' },
    { id: 'E-002', name: 'Neha Singh',    dept: 'Sales',        designation: 'Sales Manager', joined: '2020-07-01', status: 'Active', email: 'neha@acme.com' },
    { id: 'E-003', name: 'Arun Verma',    dept: 'Finance',      designation: 'Accountant',   joined: '2021-02-15', status: 'Active', email: 'arun@acme.com' },
    { id: 'E-004', name: 'Sunita Patel',  dept: 'HR',           designation: 'HR Executive', joined: '2022-09-05', status: 'On Leave', email: 'sunita@acme.com' },
    { id: 'E-005', name: 'Manoj Joshi',   dept: 'Production',   designation: 'Machine Op.',  joined: '2023-01-20', status: 'Active', email: 'manoj@acme.com' },
  ],

  /* Bank reconciliation buckets (§5.1.D) */
  bankRecon: {
    matched:   [{ date: '2026-08-20', ref: 'TXN-1001', amount: 50000,  desc: 'Customer ABC receipt' },
                { date: '2026-08-21', ref: 'TXN-1002', amount: 120000, desc: 'Vendor A payment' }],
    unmatched: [{ date: '2026-08-22', ref: 'TXN-1003', amount: 85000,  desc: 'Unknown credit' }],
    partial:   [{ date: '2026-08-23', ref: 'TXN-1004', amount: 95000,  desc: 'Partial match on PO-2011' }],
    exceptions:[{ date: '2026-08-24', ref: 'TXN-1005', amount: 250000, desc: 'Duplicate entry suspected' }],
  },

  /* AI Copilot suggested prompts (§5.8) */
  copilotPrompts: [
    'Which products have declining sales?',
    'Which materials may go out of stock?',
    'Show unpaid invoices above ₹5 lakh.',
    'Create purchase requisition for the shortage.',
  ],

  /* AI Copilot canned answers — maps question → response */
  copilotAnswers: {
    'declining': { text: 'Product A sales decreased 18% over the last 3 months, primarily in Customer Segment X.', source: 'Sales module · last 90 days' },
    'stock':     { text: '7 materials are projected to fall below safety stock within 14 days. Highest risk: IT-100 Steel Plate (12 days).', source: 'Inventory + MRP', action: { type: 'PR', title: 'Create Purchase Requisition', meta: 'PR for IT-100 × 500 units' } },
    'invoice':   { text: '12 invoices match. Total outstanding: ₹1.86 Cr.', source: 'AR module' },
    'pr':        { text: 'Draft PR-105 created for IT-100 × 500 units (₹50,000). Awaiting your approval.', source: 'Workflow Engine', action: { type: 'APPROVE', title: 'Approve PR-105', meta: 'Routes to Purchase Manager' } },
  },
};

/* ==================================================================
   API FUNCTIONS — shape identical to production
   ================================================================== */

export async function getCompanies() {
  // return (await fetch(`${API_BASE}/companies`)).json();
  return MOCK.companies;
}

export async function login(email, password) {
  // return (await fetch(`${API_BASE}/auth/login`, { method:'POST', body: JSON.stringify({email,password}), headers:{'Content-Type':'application/json'} })).json();
  const user = MOCK.demoUsers.find(u => u.email === email && u.password === password);
  if (!user) throw new Error('Invalid credentials');
  return user;
}

export async function getExecKpis() { return MOCK.execKpis; }
export async function getRoleDashboard(role) {
  const keys = MOCK.roleDashboards[role] || [];
  return keys.map(k => ({ key: k, ...MOCK.execKpis[k] }));
}
export async function getSalesTrend() { return MOCK.salesTrend; }
export async function getAiAlerts() { return MOCK.aiAlerts; }
export async function getNotifications() { return MOCK.notifications; }

export async function getCustomers() { return MOCK.customers; }
export async function getCustomer(id) { return MOCK.customers.find(c => c.id === id); }
export async function getVendors() { return MOCK.vendors; }
export async function getVendor(id) { return MOCK.vendors.find(v => v.id === id); }
export async function getItems() { return MOCK.items; }
export async function getPurchaseOrders() { return MOCK.purchaseOrders; }
export async function getPurchaseRequisitions() { return MOCK.purchaseRequisitions; }
export async function getInvoices() { return MOCK.invoices; }
export async function getProductionOrders() { return MOCK.productionOrders; }
export async function getEmployees() { return MOCK.employees; }
export async function getBankRecon() { return MOCK.bankRecon; }
export async function getCopilotPrompts() { return MOCK.copilotPrompts; }

/* AI Copilot — mock Q&A then action drafting.
   Guardrail: never executes sensitive financial transactions. */
export async function askCopilot(question) {
  // return (await fetch(`${API_BASE}/ai/copilot`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({question})})).json();
  await delay(700); // simulate network
  const q = question.toLowerCase();
  if (q.includes('declin')) return MOCK.copilotAnswers.declining;
  if (q.includes('stock') || q.includes('out of stock')) return MOCK.copilotAnswers.stock;
  if (q.includes('invoice') || q.includes('unpaid')) return MOCK.copilotAnswers.invoice;
  if (q.includes('purchase requisition') || q.includes('create pr')) return MOCK.copilotAnswers.pr;
  return { text: `I read your question: "${question}". Here's what I can see across Finance, Operations, and People data — try one of the suggested prompts for a demo answer.`, source: 'AI Copilot (demo)' };
}

/* Fixed Assets */
export async function getFixedAssets() {
  return [
    { id: 'FA-0001', name: 'CNC Milling Machine', category: 'Plant & Machinery', loc: 'Pune HQ', cost: 4800000, dep: 1440000, nbv: 3360000, life: 10, acquired: '2022-04-15', custodian: 'R. Kumar' },
    { id: 'FA-0002', name: 'Industrial Lathe',    category: 'Plant & Machinery', loc: 'Pune HQ', cost: 2200000, dep: 880000,  nbv: 1320000, life: 10, acquired: '2021-09-20', custodian: 'M. Joshi' },
    { id: 'FA-0003', name: 'Warehouse Building A',category: 'Buildings',         loc: 'Pune HQ', cost: 8400000, dep: 2100000, nbv: 6300000, life: 30, acquired: '2018-03-01', custodian: 'Facilities' },
    { id: 'FA-0004', name: 'Forklift Toyota',     category: 'Vehicles',          loc: 'Mumbai Plant', cost: 1800000, dep: 540000, nbv: 1260000, life: 8, acquired: '2023-01-10', custodian: 'S. Kumar' },
  ];
}

/* Goods Receipt */
export async function getGoodsReceipts() {
  return [
    { id: 'GRN-2011', po: 'PO-2011', vendor: 'Vendor A', date: '2026-08-24', items: 3, qty: 500, bin: 'A-12-B-01', qc: 'Passed',  status: 'Put-away done' },
    { id: 'GRN-2012', po: 'PO-2012', vendor: 'Vendor C', date: '2026-08-23', items: 5, qty: 1200, bin: 'A-12-B-02', qc: 'Pending', status: 'QC in progress' },
    { id: 'GRN-2013', po: 'PO-2014', vendor: 'Vendor A', date: '2026-08-22', items: 2, qty: 780,  bin: 'A-13-B-01', qc: 'Passed',  status: 'Awaiting invoice' },
    { id: 'GRN-2014', po: 'PO-2015', vendor: 'Vendor D', date: '2026-08-21', items: 1, qty: 95,   bin: 'B-01-A-03', qc: 'Rejected',status: 'Return to vendor' },
  ];
}

/* Work Centers */
export async function getWorkCenters() {
  return [
    { id: 'WC-01', name: 'Lathe Bay',     capacity: 40, used: 30, rate: 850,  shift: 'A · 8h' },
    { id: 'WC-02', name: 'Milling Bay',   capacity: 30, used: 27, rate: 950,  shift: 'A · 8h' },
    { id: 'WC-03', name: 'CNC Cell',      capacity: 25, used: 22, rate: 1200, shift: 'A+B · 16h' },
    { id: 'WC-04', name: 'Welding Bay',   capacity: 45, used: 38, rate: 720,  shift: 'A · 8h' },
    { id: 'WC-05', name: 'Assembly Line', capacity: 50, used: 42, rate: 600,  shift: 'A+B · 16h' },
  ];
}

/* Machines */
export async function getMachines() {
  return [
    { id: 'MCH-001', name: 'CNC Lathe Fanuc T-200',   wc: 'WC-01', make: 'Fanuc',            installed: '2022-03-12', runtime: 18420, mtbf: 420, lastMaint: '2026-06-15', status: 'Running' },
    { id: 'MCH-002', name: 'Milling Machine Haas VF-4',wc: 'WC-02', make: 'Haas',             installed: '2021-08-22', runtime: 22110, mtbf: 380, lastMaint: '2026-05-20', status: 'Running' },
    { id: 'MCH-003', name: 'CNC 5-axis DMG Mori',     wc: 'WC-03', make: 'DMG Mori',         installed: '2023-11-04', runtime: 8900,  mtbf: 520, lastMaint: '2026-08-01', status: 'Running' },
    { id: 'MCH-004', name: 'MIG Welder Lincoln',      wc: 'WC-04', make: 'Lincoln',          installed: '2020-06-18', runtime: 31200, mtbf: 250, lastMaint: '2026-04-10', status: 'Maintenance' },
    { id: 'MCH-005', name: 'Assembly Robot UR-10',    wc: 'WC-05', make: 'Universal Robots', installed: '2024-02-28', runtime: 4500,  mtbf: 610, lastMaint: '2026-07-15', status: 'Running' },
  ];
}

/* Production Orders — already exists, keep */

/* Recruitment */
export async function getRecruitments() {
  return [
    { id: 'REQ-101', title: 'Sr. Production Engineer', dept: 'Production', openings: 2, candidates: 18, posted: '2026-08-05', priority: 'High',   status: 'Interviewing' },
    { id: 'REQ-102', title: 'Sales Manager',           dept: 'Sales',      openings: 1, candidates: 12, posted: '2026-08-10', priority: 'High',   status: 'Screening' },
    { id: 'REQ-103', title: 'Accounts Executive',      dept: 'Finance',    openings: 1, candidates: 8,  posted: '2026-08-12', priority: 'Medium', status: 'Interviewing' },
    { id: 'REQ-104', title: 'Machine Operator',        dept: 'Production', openings: 3, candidates: 22, posted: '2026-08-15', priority: 'Medium', status: 'Screening' },
  ];
}

/* Tax filings */
export async function getTaxFilings() {
  return [
    { form: 'GSTR-1',         period: 'Aug 2026',  due: '2026-09-11', status: 'Pending' },
    { form: 'GSTR-3B',        period: 'Aug 2026',  due: '2026-09-20', status: 'Pending' },
    { form: 'TDS 26Q',        period: 'Q1 FY27',   due: '2026-07-31', status: 'Filed' },
    { form: 'GSTR-9',         period: 'FY 2025-26',due: '2026-12-31', status: 'Upcoming' },
    { form: 'Advance Tax Q2', period: 'Q2 FY27',   due: '2026-09-15', status: 'Pending' },
  ];
}

/* Users */
export async function getUsers() {
  return [
    { name: 'Rahul Mehta',  email: 'ceo@acme.com',       role: 'CEO',              status: 'Active',    lastLogin: '2026-08-24 08:15' },
    { name: 'Anita Sharma', email: 'cfo@acme.com',       role: 'CFO',              status: 'Active',    lastLogin: '2026-08-24 09:02' },
    { name: 'Vikram Rao',   email: 'purchase@acme.com',  role: 'Purchase Manager', status: 'Active',    lastLogin: '2026-08-24 09:30' },
  ];
}

/* Integrations */
export async function getIntegrations() {
  return [
    { name: 'Tally Prime',        desc: 'Sync GL entries',              icon: 'book',     status: 'Connected' },
    { name: 'Zoho CRM',           desc: 'Lead & opportunity sync',      icon: 'users',    status: 'Connected' },
    { name: 'Razorpay',           desc: 'Payment gateway',              icon: 'dollar-sign',status: 'Connected' },
    { name: 'WhatsApp Business',  desc: 'Notification channel',         icon: 'send',     status: 'Available' },
  ];
}

/* Utility */
function delay(ms) { return new Promise(r => setTimeout(r, ms)); }