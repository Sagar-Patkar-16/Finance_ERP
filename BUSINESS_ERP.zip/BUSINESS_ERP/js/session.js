/* ============================================================
   Session helpers — thin wrapper around localStorage
   ============================================================ */
import { getSession, setSession, clearSession, requireAuth } from './app.js';

export const Session = {
  get() { return getSession(); },
  set(user) { setSession(user); },
  clear() { clearSession(); },
  require() { return requireAuth(); },
  isCEO() { return this.get()?.role === 'CEO'; },
  isCFO() { return this.get()?.role === 'CFO'; },
  isPurchaseMgr() { return this.get()?.role === 'Purchase Manager'; },
  isWarehouseMgr() { return this.get()?.role === 'Warehouse Manager'; },
  isProductionMgr() { return this.get()?.role === 'Production Manager'; },
  isHRMgr() { return this.get()?.role === 'HR Manager'; },
  has(role) { return this.get()?.role === role; },
};