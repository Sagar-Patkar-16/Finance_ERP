# ERP Platform — AI-Powered Modular ERP (Demo Build)

A working, interactive front-end prototype of the AI-Powered Modular ERP
described in the Project Scope Document (v1.0, 24 Aug 2026).

Built with **HTML + CSS + Vanilla JS + Chart.js**. Zero build step.
Open `index.html` and it runs.

## Run

    # Option 1: open directly
    open index.html            # macOS
    start index.html           # Windows
    xdg-open index.html        # Linux

    # Option 2: local server (recommended — module imports work best over HTTP)
    npx serve .
    # or
    python -m http.server 8000

## Demo accounts (any password)

    ceo@acme.com        → CEO              (full exec dashboard)
    cfo@acme.com        → CFO              (finance widgets)
    purchase@acme.com   → Purchase Manager
    warehouse@acme.com  → Warehouse Manager
    production@acme.com → Production Manager
    hr@acme.com         → HR Manager

Role drives which KPI widgets render on the dashboard (§10.5).

## Features implemented

- Login → company-aware session → role-based dashboard
- Dark / Light theme (persists)
- Comfortable / Compact density for tables
- Global search (⌘K / Ctrl+K)
- Notification centre drawer (5-level severity palette)
- 360° View pattern reused across entities (§10.4)
- CRM pipeline Kanban with drag-and-drop (§5.2)
- RFQ side-by-side comparison (§5.3)
- Bank reconciliation with 4 buckets (§5.1.D)
- Cash Flow waterfall chart (§5.1.F)
- MRP with replenishment recommendations (§5.5)
- Capacity planning stacked bars (§5.6)
- AI Copilot chat with action cards + guardrail (§5.8)
- Anomaly Alert Centre
- No-Code WHEN/IF/THEN automation list
- RBAC roles matrix (§8)
- Audit trail table (§9)

## Folder structure

    erp-platform/
    ├── index.html
    ├── pages/            ← every module screen (see nav.js for full list)
    ├── css/              ← tokens, base, components, layout, responsive
    ├── js/
    │   ├── api.js        ← ALL mock data (single swap point for real backend)
    │   ├── app.js        ← theme, session, formatting
    │   ├── components.js ← KPI, tables, chips, modals, toasts, stepper
    │   ├── nav.js        ← sidebar, topbar, notification drawer, search
    │   ├── charts.js     ← Chart.js wrappers (line, bar, doughnut, waterfall, stacked)
    │   └── dashboard.js
    └── assets/

## Replacing mock data with a real backend

Everything lives behind `js/api.js`. Every function has the pattern:

    export async function getCustomers() {
      // return (await fetch(`${API_BASE}/customers`)).json();  ← production
      return MOCK.customers;                                    ← mock now
    }

To go live:
1. Set `API_BASE` at the top of `js/api.js` to your FastAPI host.
2. Comment the `return MOCK.x` line and uncomment the `fetch(...)` line per function.
3. For AI Copilot real-time streaming, replace `askCopilot()` with a POST to
   `/ai/copilot` — the response shape `{ text, source?, action? }` is unchanged.
4. For alerts, add a WebSocket subscriber that pushes into the notification store.

## Architectural rules respected (per scope §4)

- All data access flows through `api.js` (the "API Gateway" boundary).
- Charts and AI never write directly to mock "tables" — they call the same
  functions a human would.
- AI Copilot never executes financial transactions — it drafts actions with
  human approval (guardrail rendered in `ai-copilot.html`).
- Audit trail captures Created/Modified By+Date, Prev/New Value, Reason, IP (§9).
- Master data (customers, vendors, items, employees) is shared across modules —
  not duplicated per screen.

## Not in scope

- No IoT / hardware control (this is a business SaaS ERP).
- No real authentication backend — session is stored in `localStorage`.
- No PWA / service worker (planned Phase 2, §11).